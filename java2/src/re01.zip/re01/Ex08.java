package re01;

public class Ex08 {
	public static void main(String[] args) {
		char c = 'A';
		System.out.println(c);
		int a = c;
		System.out.println(a);
	}
}
