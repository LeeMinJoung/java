package re01;

public class Ex03 {
	public static void main(String[] args) {
		int a = 5;
		System.out.println(a);
		double b;
		b = 5.5;
		double c = 7.7;
		double d = 5;
		System.out.println(d);
		System.out.println(b);
		System.out.println(c);
		System.out.println(a+b);
	}
}
