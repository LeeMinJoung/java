package re01;

public class Ex10 {
	public static void main(String[] args) {
		int a = 97;
		char b = (char)a;
		System.out.println(a);
		System.out.println(b);
		
		double x = 10.5;
		int y = (int)x;
		System.out.println(x);
		System.out.println(y);
		
		double z = (double)y;
		System.out.println(z);
	}
}
