package re01;

public class Ex11 {
	public static void main(String[] args) {
		int a = 130;
		byte b = (byte)a;
		System.out.println(b);
		
		float f = 5.7f;
		System.out.println(f);
		long c = 100000*100000L;
		System.out.println(c);
	}
}
