package re01;

public class Ex02 {
	public static void main(String[] args) {
		int a;
		a = 10;
		System.out.println(a);
		
		a = 20;
		System.out.println(a);
		int b = 30;
		System.out.println(b);
		int c = b;
		System.out.println(c);
		int d = 
				c + a;
		System.out.println(d);
		
	}
}
