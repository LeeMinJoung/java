package re01;

public class Ex05 {
	public static void main(String[] args) {
		String a;
		a = "hello";
		System.out.println(a);
		
		String b = " ";
		System.out.println(b);
		
		String c = "hello world";
		System.out.println(c);
	}
}
