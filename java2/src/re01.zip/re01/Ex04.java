package re01;

public class Ex04 {
	public static void main(String[] args) {
		boolean a;
		a = true;
		System.out.println(a);
		boolean b = false;
		System.out.println(b);
		b = true;
		System.out.println(b);
		System.out.println(b);
		
		int x = 10;
		int y = 5;
		boolean z = x>y;
		System.out.println(z);
		
		z = (x != y);
		System.out.println("z의 결과는 : "+z);
	}
}
