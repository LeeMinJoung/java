package re01;

public class Ex09 {
	public static void main(String[] args) {
		char a = 'a';
		int b = (int)a;
		System.out.println(a);
		System.out.println(b);
		
		double c = (double)b;
		System.out.println(c);
	}
}
