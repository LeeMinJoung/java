package re01;

public class Ex06 {
	public static void main(String[] args) {
		int a = 10;
		int b = 20;
		String c = "숫자는 : ";
		System.out.println(a+b);
		System.out.println(c+b);
		System.out.println("내가 가진 "+c+a);
		
		String x = "hello";
		String y = "world";
		System.out.println(x+" "+y);		
	}
}
