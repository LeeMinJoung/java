package re02;

public class Ex04 {
	public static void main(String[] args) {
		int a = 10;
		int b = 10;
//		System.out.println(++a + b); // 11 + 10
//		System.out.println(++a + ++b); // 11 + 11
//		System.out.println(a++ + b++); // 10 + 10
//		System.out.println(++a + ++a); // 11 + 12
		System.out.println(a++ + a++); // 10 + 11
		System.out.println(a);
	}
}
