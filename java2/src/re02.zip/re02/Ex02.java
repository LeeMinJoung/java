package re02;

public class Ex02 {
	public static void main(String[] args) {
		int a = 10;
//		System.out.println(a++); // 10
//		System.out.println(++a); // 12
//		System.out.println(a++); // 12
//		System.out.println(a++); // 13
//		System.out.println(++a); // 15
//							a++; // 16
//		System.out.println(++a); // 17
//		System.out.println(a); //17
		
		System.out.println(a--); // 10
		System.out.println(--a); // 8
		System.out.println(a--); // 8
		System.out.println(a--); // 7
		System.out.println(--a); // 5
							a--; // 4
		System.out.println(--a); // 3
		System.out.println(a); //3
		
	}
}
