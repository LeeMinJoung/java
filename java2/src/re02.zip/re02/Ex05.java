package re02;

public class Ex05 {
	public static void main(String[] args) {
		System.out.println(10 > 0);
		System.out.println(10 == 0);
		System.out.println(10 == 0+10);
		System.out.println(10 != 0);
		
		int a = 10, b = 0;
		System.out.println(a >= b);
		System.out.println(a == b+10);
		System.out.println(a != b);
	}
}
