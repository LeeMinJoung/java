package re02;

public class Ex03 {
	public static void main(String[] args) {
		int a = 10;
		double b = 5.5;
		System.out.println(a+b);
		
		int c = (int)(a+b);
		System.out.println(c);
		
		double d = (double)(a+b);
		System.out.println(d);
		
		int e = 10;
		System.out.println(e%2 == 0);
		System.out.println(e%3 == 1);
	}
}
