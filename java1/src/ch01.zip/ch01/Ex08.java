package ch01;

public class Ex08 {
	public static void main(String[] args) {
		char c = 'A';
		// 한글자의 문자(키보드에 있는 모든 문자)만 사용 가능
		// 반드시 ''(작은 따옴표)안에 사용해야한다
		// 아스키코드표
		System.out.println(c);
		int a = c;
		System.out.println(a);
		// 'A' = 65, 'a' = 97, '0' = 48
	}
}
