package ch01;

public class Ex01 {
	public static void main(String[] args) {
		System.out.println("안녕하세요");
		// 한줄 주석
		/* 여러줄 주석
		. : 알고있다, 가지고있다
		;(세미콜론) : 실행문 (문장의 마침표)
		클래스 이름 명명 규칙
			겹치지않게 사용
			구별할 것을 줘라 (_붙이기, 숫자붙이기 등등)
			특수문자 (_, $) 두가지만 사용 가능
			첫글자 숫자, 특수문자가 오면 안된다.
			첫글자 대문자 사용
			예) SportsScore : 단어의 조합은 첫글자 대문자로
			들여쓰기 : Tab
			실행 단축키 : Ctrl + F11
		 */
	}
}